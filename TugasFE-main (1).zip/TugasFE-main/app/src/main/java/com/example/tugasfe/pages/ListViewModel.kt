package com.example.tugasil.pages

class ListViewModel(
) {
}