package com.example.tugasfe.model

data class Game(
    val id: String,
    val image: Int,
    val title: String,
    val detail: String
)