package com.example.tugasil.navbar

import androidx.compose.ui.graphics.vector.ImageVector

class BottomNavItem(
    val title: String,
    val icon: ImageVector,
    val screen: Screen
) {

}